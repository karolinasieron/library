from setuptools import setup

setup(
    name='mojabiblioteka',
    version='1.0.0',
    description='This is my first python library.',
    url='',
    author='karolinasieron',
    author_email='ksieron@st.swps.edu.pl',
    license='for internal use',
    keywords='library',
)